# DevLink Production Deployment Guide

## Overview
This directory contains all files needed to deploy DevLink to your website.

## Files Structure
```
deploy/
├── downloads/                    # Binary files for users to download
│   ├── devlink-linux-amd64      # Linux AMD64 binary
│   ├── devlink-linux-arm64      # Linux ARM64 binary
│   ├── devlink-linux-arm        # Linux ARM binary
│   ├── devlink-darwin-amd64     # macOS Intel binary
│   ├── devlink-darwin-arm64     # macOS Apple Silicon binary
│   ├── devlink-windows-amd64.exe # Windows binary
│   ├── checksums.txt            # SHA256 checksums for verification
│   └── release-info.txt         # Release information
├── install.sh                   # Website installer script
├── download.html                # Download page HTML
└── DEPLOYMENT.md                # This file
```

## Deployment Steps

### 1. Upload to Your Website
Upload the entire `deploy/` directory to your website's root directory.

### 2. Update URLs
Before deploying, update these URLs in the files:
- `install.sh`: Replace `https://your-website.com` with your actual domain
- `download.html`: Replace `https://your-website.com` with your actual domain

### 3. Set Permissions
Ensure the binary files are executable:
```bash
chmod +x /path/to/your/website/downloads/devlink-*
```

### 4. Test Installation
Test the installation from your website:
```bash
curl -sSL https://your-website.com/install.sh | bash
```

## User Experience

### Download Page
Users can visit `https://your-website.com/download.html` to:
- See all available platforms
- Download the appropriate binary
- Get installation instructions

### One-Command Install
Users can install with a single command:
```bash
curl -sSL https://your-website.com/install.sh | bash
```

### Manual Installation
Users can also:
1. Download the binary manually
2. Make it executable: `chmod +x devlink-[platform]`
3. Move to PATH: `sudo mv devlink-[platform] /usr/local/bin/devlink`

## Security Features

### Checksums
All binaries include SHA256 checksums for verification:
```bash
# Download checksums
curl -O https://your-website.com/downloads/checksums.txt

# Verify a download
sha256sum -c checksums.txt
```

### HTTPS Required
Always serve the installer over HTTPS to prevent tampering.

## Support

### Common Issues
- **Permission denied**: Ensure binaries are executable
- **Command not found**: Check if PATH includes installation directory
- **Download failed**: Verify download URLs are correct

### Troubleshooting
1. Check file permissions
2. Verify download URLs
3. Test with different browsers/curl
4. Check server logs for errors

## Updates

### New Releases
1. Run `./build-all.sh` to build new binaries
2. Run `./deploy.sh` to create new deployment package
3. Upload new files to website
4. Update version numbers in HTML and scripts

### Backward Compatibility
- Keep old versions available for users who can't update immediately
- Consider using semantic versioning for releases
- Provide migration guides for major version changes
