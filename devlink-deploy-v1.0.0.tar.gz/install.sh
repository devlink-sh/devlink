#!/bin/bash

# DevLink Website Installer
# This script downloads and installs DevLink from the website
# Version: 1.0.0

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Logo
echo -e "${CYAN}"
cat << 'LOGO'
 ____             _     _       _    
|  _ \  _____   _| |   (_)_ __ | | __
| | | |/ _ \ \ / / |   | | '_ \| |/ /
| |_| |  __/\ V /| |___| | | | |   < 
|____/ \___| \_/ |_____|_|_| |_|_|\_\

🚀 DevLink - Website Installation
LOGO
echo -e "${NC}"

# Website configuration
WEBSITE_URL="https://your-website.com"
DOWNLOAD_PATH="/downloads"

# Function to detect OS
detect_os() {
    case "$(uname -s)" in
        Linux*)     echo "linux";;
        Darwin*)    echo "darwin";;
        CYGWIN*)   echo "windows";;
        MINGW*)    echo "windows";;
        MSYS*)     echo "windows";;
        *)          echo "unknown";;
    esac
}

# Function to detect architecture
detect_arch() {
    case "$(uname -m)" in
        x86_64)    echo "amd64";;
        aarch64)   echo "arm64";;
        arm64)     echo "arm64";;
        armv7l)    echo "arm";;
        armv6l)    echo "arm";;
        *)         echo "amd64";;
    esac
}

# Function to get download URL
get_download_url() {
    local os=$1
    local arch=$2
    
    case "$os" in
        "linux")
            case "$arch" in
                "amd64") echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-linux-amd64";;
                "arm64") echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-linux-arm64";;
                "arm")   echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-linux-arm";;
                *)       echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-linux-amd64";;
            esac
            ;;
        "darwin")
            case "$arch" in
                "amd64") echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-darwin-amd64";;
                "arm64") echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-darwin-arm64";;
                *)       echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-darwin-arm64";;
            esac
            ;;
        "windows")
            echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-windows-amd64.exe"
            ;;
        *)
            echo "$WEBSITE_URL$DOWNLOAD_PATH/devlink-linux-amd64"
            ;;
    esac
}

# Function to download with progress
download_file() {
    local url=$1
    local output=$2
    
    if command -v curl >/dev/null 2>&1; then
        echo -e "${YELLOW}📥 Downloading with curl...${NC}"
        curl -L -o "$output" "$url" --progress-bar
    elif command -v wget >/dev/null 2>&1; then
        echo -e "${YELLOW}📥 Downloading with wget...${NC}"
        wget -O "$output" "$url" --progress=bar:force
    else
        echo -e "${RED}❌ Error: Neither curl nor wget found. Please install one and try again.${NC}"
        exit 1
    fi
}

# Function to install on Linux/macOS
install_unix() {
    local download_url=$1
    local binary_name="devlink"
    local temp_dir=$(mktemp -d)
    
    echo -e "${YELLOW}📥 Downloading DevLink...${NC}"
    
    # Download binary to temp directory
    cd "$temp_dir"
    download_file "$download_url" "$binary_name"
    
    # Make executable
    chmod +x "$binary_name"
    
    # Install globally
    echo -e "${YELLOW}📦 Installing DevLink globally...${NC}"
    
    local installed_path=""
    if [ -w /usr/local/bin ]; then
        sudo cp "$binary_name" /usr/local/bin/
        installed_path="/usr/local/bin/devlink"
        echo -e "${GREEN}✅ Installed to $installed_path${NC}"
    elif [ -w /usr/bin ]; then
        sudo cp "$binary_name" /usr/bin/
        installed_path="/usr/bin/devlink"
        echo -e "${GREEN}✅ Installed to $installed_path${NC}"
    else
        echo -e "${YELLOW}📁 Installing to user directory...${NC}"
        mkdir -p ~/.local/bin
        cp "$binary_name" ~/.local/bin/
        installed_path="$HOME/.local/bin/devlink"
        echo -e "${GREEN}✅ Installed to $installed_path${NC}"
        
        # Add to PATH
        if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
            echo -e "${YELLOW}💡 Adding to PATH...${NC}"
            if [ -f ~/.bashrc ]; then
                echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
            fi
            if [ -f ~/.zshrc ]; then
                echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
            fi
            if [ -f ~/.profile ]; then
                echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.profile
            fi
            echo -e "${YELLOW}💡 Please restart your terminal or run: source ~/.bashrc${NC}"
        fi
    fi
    
    # Clean up
    cd - > /dev/null
    rm -rf "$temp_dir"
    
    echo "$installed_path"
}

# Function to install on Windows
install_windows() {
    local download_url=$1
    local binary_name="devlink.exe"
    local temp_dir=$(mktemp -d)
    
    echo -e "${YELLOW}📥 Downloading DevLink...${NC}"
    
    # Download binary to temp directory
    cd "$temp_dir"
    download_file "$download_url" "$binary_name"
    
    # Install globally
    echo -e "${YELLOW}📦 Installing DevLink globally...${NC}"
    
    local installed_path=""
    if [ -d "/c/Program Files" ]; then
        sudo mkdir -p "/c/Program Files/devlink"
        sudo cp "$binary_name" "/c/Program Files/devlink/"
        installed_path="C:\\Program Files\\devlink\\devlink.exe"
        echo -e "${GREEN}✅ Installed to $installed_path${NC}"
    else
        echo -e "${YELLOW}💡 Please manually copy devlink.exe to a directory in your PATH${NC}"
        installed_path="./devlink.exe"
    fi
    
    # Clean up
    cd - > /dev/null
    rm -rf "$temp_dir"
    
    echo "$installed_path"
}

# Main installation logic
main() {
    echo -e "${BLUE}🔍 Detecting your system...${NC}"
    
    OS=$(detect_os)
    ARCH=$(detect_arch)
    
    echo -e "${GREEN}✅ Detected: $OS ($ARCH)${NC}"
    
    # Check if already installed
    if command -v devlink >/dev/null 2>&1; then
        echo -e "${YELLOW}⚠️  DevLink is already installed!${NC}"
        echo -e "${YELLOW}Current version: $(devlink --version 2>/dev/null || echo 'unknown')${NC}"
        read -p "Do you want to reinstall? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo -e "${GREEN}✅ Keeping existing installation${NC}"
            exit 0
        fi
    fi
    
    # Get download URL
    DOWNLOAD_URL=$(get_download_url "$OS" "$ARCH")
    
    echo -e "${BLUE}📡 Download URL: $DOWNLOAD_URL${NC}"
    
    # Install based on OS
    if [ "$OS" = "windows" ]; then
        INSTALLED_PATH=$(install_windows "$DOWNLOAD_URL")
    else
        INSTALLED_PATH=$(install_unix "$DOWNLOAD_URL")
    fi
    
    # Test installation
    echo -e "${YELLOW}🧪 Testing installation...${NC}"
    if [ -f "$INSTALLED_PATH" ] && [ -x "$INSTALLED_PATH" ]; then
        echo -e "${GREEN}✅ Installation successful!${NC}"
        
        echo -e "${GREEN}"
        echo "🎉 DevLink installed successfully!"
        echo "🚀 You can now use 'devlink' command from anywhere!"
        echo ""
        echo "Try: devlink --help"
        echo -e "${NC}"
        
        # Show help
        echo -e "${CYAN}📚 Quick Start:${NC}"
        echo -e "  devlink --help          # Show all commands"
        echo -e "  devlink env --help      # Environment management"
        echo -e "  devlink git --help      # Git utilities"
        echo -e "  devlink pair --help     # Pair programming tools"
        echo -e "  devlink db --help       # Database utilities"
        echo -e "  devlink registry --help # Registry management"
        
    else
        echo -e "${RED}❌ Installation failed! Please check the errors above.${NC}"
        exit 1
    fi
}

# Error handling
trap 'echo -e "\n${RED}❌ Installation interrupted${NC}"; exit 1' INT TERM

# Run main function
main "$@"
